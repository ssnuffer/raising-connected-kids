# Raising Connected Kids — group website

A one-page site for the 6-week parenting group, matching the Mental Refinery brand.

## What's in here

```
index.html            the whole site (one file — all CSS is inline)
assets/flyer.png      the flyer, shown in the hero and clickable to full size
assets/logo-mark.png  the Mental Refinery logo mark
assets/favicon.png    browser tab icon
README.md             this file
```

## Put it live on GitHub Pages (about 3 minutes)

1. Go to github.com → **New repository**. Name it `raising-connected-kids`. Make it **Public**. Don't add a README (there's one here). Create it.
2. On the new repo page click **uploading an existing file**.
3. Drag in `index.html`, `README.md`, **and the whole `assets` folder** (drag the folder itself so the files stay inside it). Click **Commit changes**.
4. Go to **Settings → Pages**. Under "Build and deployment", set Source = **Deploy from a branch**, Branch = **main**, folder = **/ (root)**. Save.
5. Wait ~1 minute, then refresh that page. Your live URL appears at the top:

   `https://YOUR-USERNAME.github.io/raising-connected-kids/`

That link is live and shareable immediately — put it in the flyer QR code, emails, and social posts.

### Want a custom address like `parenting.thementalrefinery.com`?

In **Settings → Pages → Custom domain**, enter the subdomain, then add a `CNAME`
record at your domain registrar pointing that subdomain to `YOUR-USERNAME.github.io`.
GitHub will issue the HTTPS certificate automatically.

### Alternative: drop it into your existing site instead

If you'd rather it live at `thementalrefinery.com/parenting-group/`, upload
`index.html` and the `assets` folder into a folder named `parenting-group` in the
repo for your main site. All the paths in the file are relative, so it works either
way with no edits.

## Link it from your main site

Your main site already has a "Parenting Group" section (`#parenting-group`) and a
"Parenting Group" service card. In `index.html` for your main site, point those
links at the new URL. Two edits:

**1. The service card link** — find `Details &amp; registration &rarr;` and change:

```html
<a class="svc-link" href="#parenting-group">Details &amp; registration &rarr;</a>
```

to:

```html
<a class="svc-link" href="https://YOUR-USERNAME.github.io/raising-connected-kids/">Details &amp; registration &rarr;</a>
```

**2. The nav link** — find `<li><a href="#parenting-group">Parenting Group</a></li>`
and swap the `href` for the same URL.

Optionally, in the green "Now enrolling" band, change the "Register now" button to
point at the new site instead of straight to the Google Form, so parents see the full
details and both payment options first.

## Updating it later

Everything is in `index.html`. The things most likely to change:

| What | Where to look |
|---|---|
| Dates, price, seat counts | Search for `September 1`, `$675`, `$900`, `August 25` |
| Registration form link | Search for `docs.google.com/forms` |
| Stripe payment links | Search for `buy.stripe.com` — individual first, couple second |
| Week descriptions | The `<details class="week">` blocks |
| FAQ | The `faq-list` section |

To edit on GitHub: open `index.html` in your repo, click the pencil icon, make the
change, click **Commit changes**. The live site updates in about a minute.

### For the next cohort

Rather than overwriting, you can copy `index.html` and update the dates — but the
simplest approach is to edit in place each season, since the URL stays the same and
anything you've already printed or posted keeps working.

## Notes

- The Stripe buttons open Stripe's own secure checkout pages. Nothing sensitive
  touches this site.
- The registration form and payment are two separate steps by design — the form
  tells you who's coming and which seat type they want, the payment holds the seat.
- Currency, receipts and refunds are all managed from your Stripe dashboard.
